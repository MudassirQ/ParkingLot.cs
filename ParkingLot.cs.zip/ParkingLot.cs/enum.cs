﻿namespace ParkingLot.Enum
{
    public enum SlotType
    {
        Small,
        Medium,
        Large
    }
    public enum VehicleType
    {
        Hatchback,
        SedanCompactSUV,
        SUVorLarge
    }

}